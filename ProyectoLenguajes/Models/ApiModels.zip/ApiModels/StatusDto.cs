﻿namespace ProyectoLenguajes.Models.ApiModels
{
    public class StatusDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
